#ifndef __LED_H
#define __LED_H

extern void led_init();
extern void led_on();
extern void led_off();
extern void led_tog();

#endif

