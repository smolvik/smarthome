#ifndef __DBG_H
#define __DBG_H

extern void dbg_init();

#endif
